package com.example.project.weatherapplication;

/**
 * Created by Monika on 14-07-2018.
 */

public class ListLocationActivity {
}
