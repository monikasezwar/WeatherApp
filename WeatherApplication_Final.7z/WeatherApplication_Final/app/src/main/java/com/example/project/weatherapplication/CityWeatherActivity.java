package com.example.project.weatherapplication;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

/**
 * Created by Monika on 14-07-2018.
 */

public class CityWeatherActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.single_city_weather);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
