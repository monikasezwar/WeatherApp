package com.example.project.weatherapplication.presenter;

import com.example.project.weatherapplication.view.AddLocationView;
import com.hannesdorfmann.mosby.mvp.MvpBasePresenter;

import java.util.ArrayList;


public class AddLocationPresenter extends MvpBasePresenter<AddLocationView> {


    ArrayList<String> mCityList;


    public void addCity(String city) {

        if (mCityList == null) {
            mCityList = new ArrayList<String>();
        }

        mCityList.add(city);



        //getView().addCity();
    }

    public  ArrayList<String> getCitiesList(){
        return mCityList;
    }




}
