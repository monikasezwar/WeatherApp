package com.example.project.weatherapplication.presenter;

/**
 * Created by Monika on 13-07-2018.
 */



import com.example.project.weatherapplication.adapter.WeatherAdapter;
import com.example.project.weatherapplication.model.WeatherCityInfo;
import com.example.project.weatherapplication.view.MainActivityWeatherView;
import com.hannesdorfmann.mosby.mvp.MvpBasePresenter;

import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;

public class WeatherPresenter extends MvpBasePresenter<MainActivityWeatherView> {

    public void doObtainWeather(double lat, double lon) {
        if (getView() == null) {
            return;
        }

        getView().showLoading();

        WeatherAdapter.getInstance().getCurrentWeatherByLatLong(lat, lon)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<WeatherCityInfo>() {
                    @Override
                    public void onCompleted() {
                    }

                    @Override
                    public void onError(Throwable e) {
                        getView().showError(e.getMessage());
                    }

                    @Override
                    public void onNext(WeatherCityInfo weather) {
                        getView().onWeatherObtained(weather);
                    }
                });
    }
}
