package com.example.project.weatherapplication.view;


import com.hannesdorfmann.mosby.mvp.MvpView;

public interface AddLocationView extends MvpView {

    public void addCity();
}
