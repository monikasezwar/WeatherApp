package com.example.project.weatherapplication;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.weatherapplication.model.WeatherCityInfo;
import com.example.project.weatherapplication.presenter.WeatherPresenter;
import com.example.project.weatherapplication.view.MainActivityWeatherView;
import com.example.project.weatherapplication.view.WeatherViewAdapter;
import com.hannesdorfmann.mosby.mvp.MvpActivity;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity
        extends MvpActivity<MainActivityWeatherView, WeatherPresenter>
        implements MainActivityWeatherView, onLocationCallback{

    @Bind(R.id.city_name)
    TextView cityText;

    @Bind(R.id.current_date)
    TextView currentDateText;

    @Bind(R.id.weather_text)
    TextView conditionText;

    @Bind(R.id.temp_text)
    TextView tempText;

    @Bind(R.id.humidity_text)
    TextView humidityText;

    @Bind(R.id.wind_text)
    TextView windText;

    @Bind(R.id.current_city_list)
    RecyclerView recyclerView;

    @Bind(R.id.add_location)
    Button addLocation;

    private LocationManager locationManager;
    private GPSTracker gps;
    private String provider;
    private final int REQUEST_LOCATION = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        //progressDialog = new ProgressDialog(this);
        //progressDialog.setMessage(getString(R.string.please_wait));

        gps = new GPSTracker(this);

        // getLatitudeLongitude();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);

        } else {

            if (isNetworkConnectionAvailable()) {
                getCurrentCityWeather();
            }

        }
    }

    @OnClick(R.id.add_location)
    public void startAddLocationActivity() {
        Intent intent = new Intent(this, AddLocationActivity.class);
        startActivity(intent);
    }

   /* @OnClick(R.id.getCordinatesButton)
    public void getLatitudeLongitude() {
        GeocodingLocation locationAddress = new GeocodingLocation();
        String address = cityName.getText().toString();
        locationAddress.getAddressFromLocation(address,
                getApplicationContext(), new GeocoderHandler());
    }*/

    /*private class GeocoderHandler extends Handler {
        @Override
        public void handleMessage(Message message) {
            String locationAddress;
            switch (message.what) {
                case 1:
                    Bundle bundle = message.getData();
                    locationAddress = bundle.getString("address");
                    break;
                default:
                    locationAddress = null;
            }
            latlongText.setText(locationAddress);
        }
    }*/

    public void getCurrentCityWeather() {
        if (gps.canGetLocation()) {
            presenter.doObtainWeather(gps.getLatitude(), gps.getLongitude());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        ButterKnife.unbind(this);
    }

    @NonNull
    @Override
    public WeatherPresenter createPresenter() {
        return new WeatherPresenter();
    }

    @Override
    public void showLoading() {
        //progressDialog.show();
    }

    @Override
    public void hideLoading() {
        //progressDialog.hide();
    }

    @Override
    public void showError(String error) {
        //hideLoading();
        //Snackbar.make(rootLayout, error, Snackbar.LENGTH_LONG).show();
    }

    @Override
    public void onWeatherObtained(WeatherCityInfo w) {
        //hideLoading();
        showWeather(w);

        showAll14DaysWeather(w);
    }

    private void showWeather(WeatherCityInfo w) {


        String city = w.getCity().getName();

        String currentDate = w.getList().get(0).getDtTxt();

        String condition = w.getList().get(0).getWeather().get(0).getDescription();

        String temp = w.getList().get(0).getMain().getTemp() +
                getString(R.string.celsius);

        String humidity = getString(R.string.humidity) + ": " +
                w.getList().get(0).getMain().getHumidity() + "%";

        String wind = getString(R.string.wind_speed) + ": " +
                w.getList().get(0).getWind().getSpeed()+ " m/s";

        cityText.setText(city);
        currentDateText.setText(currentDate);
        conditionText.setText(condition);
        tempText.setText(temp);
        humidityText.setText(humidity);
        windText.setText(wind);
    }

    private void showAll14DaysWeather(WeatherCityInfo w) {

        LinearLayoutManager horizontalLayoutManagaer  = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);

        //GridLayoutManager gridLayoutManager = new GridLayoutManager(MainActivity.this, 14);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 1, GridLayoutManager.HORIZONTAL, false);



        recyclerView = (RecyclerView)findViewById(R.id.current_city_list);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setHasFixedSize(true);

        WeatherViewAdapter recyclerViewAdapter = new WeatherViewAdapter(MainActivity.this, w.getList(), WeatherViewAdapter.VIEWTYPE_VERTICAL);
        recyclerView.setAdapter(recyclerViewAdapter);

    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public void onCurrentLocationChanged(Location location) {
        getCurrentCityWeather();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_LOCATION) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    if (isNetworkConnectionAvailable()) {
                        getCurrentCityWeather();
                    }
                }

            }else{

                Toast.makeText(MainActivity.this, getString(R.string.permission_notice), Toast.LENGTH_LONG).show();
            }
        }
    }

    public void checkNetworkConnection(){
        AlertDialog.Builder builder =new AlertDialog.Builder(this);
        builder.setTitle("No internet Connection");
        builder.setMessage("Please turn on internet connection to continue");
        builder.setNegativeButton("close", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public boolean isNetworkConnectionAvailable(){
        ConnectivityManager cm =(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnected();
        if(isConnected) {
            Log.d("Network", "Connected");
            return true;
        }
        else{
            checkNetworkConnection();
            Log.d("Network","Not Connected");
            return false;
        }
    }



}


