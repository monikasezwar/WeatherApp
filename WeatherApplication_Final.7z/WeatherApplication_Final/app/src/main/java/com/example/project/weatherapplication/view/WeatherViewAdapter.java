package com.example.project.weatherapplication.view;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.project.weatherapplication.R;


import java.util.List;

public class WeatherViewAdapter extends RecyclerView.Adapter<WeatherViewHolder> {

    private List<com.example.project.weatherapplication.model.List> mDailyWeatherList;

    protected Context context;

    public static final int VIEWTYPE_HORIZONTAL = 1;

    public static final int VIEWTYPE_VERTICAL = 2;

    private int mViewType = VIEWTYPE_HORIZONTAL;

    public WeatherViewAdapter(Context context, List<com.example.project.weatherapplication.model.List> weatherList, int orientation) {
        this.mDailyWeatherList = weatherList;
        this.context = context;
        this.mViewType  = orientation;
    }



    @Override
    public WeatherViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        WeatherViewHolder viewHolder = null;

        View layoutView;
        if(mViewType == VIEWTYPE_HORIZONTAL){
            layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.weather_daily_list_horizontal, parent, false);
        }else {
            layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.weather_daily_list_vertical, parent, false);
        }
        viewHolder = new WeatherViewHolder(layoutView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(WeatherViewHolder holder, int position) {

        Log.d("MONIKA", "DATE = "+mDailyWeatherList.get(position).getDtTxt());

        holder.dayOfWeek.setText(mDailyWeatherList.get(position).getDtTxt());

        holder.temp.setText(String.valueOf((mDailyWeatherList.get(position).getMain().getTemp() + context.getString(R.string.celsius))));

        holder.weather.setText(mDailyWeatherList.get(position).getWeather().get(0).getDescription());

        holder.wind.setText(String.valueOf(mDailyWeatherList.get(position).getWind().getSpeed()+ " m/s"));

        holder.humidty.setText(String.valueOf(mDailyWeatherList.get(position).getMain().getHumidity() + "%"));

    }

    @Override
    public int getItemCount() {
        return mDailyWeatherList.size();
    }

}
