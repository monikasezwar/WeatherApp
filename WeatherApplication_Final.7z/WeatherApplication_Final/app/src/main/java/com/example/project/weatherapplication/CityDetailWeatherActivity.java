package com.example.project.weatherapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.weatherapplication.model.WeatherCityInfo;
import com.example.project.weatherapplication.presenter.CityDetailWeatherPresenter;
import com.example.project.weatherapplication.view.CityDetailWeatherView;
import com.example.project.weatherapplication.view.WeatherViewAdapter;
import com.hannesdorfmann.mosby.mvp.MvpActivity;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by Monika on 14-07-2018.
 */


public class CityDetailWeatherActivity extends MvpActivity<CityDetailWeatherView, CityDetailWeatherPresenter> implements CityDetailWeatherView {


    @Bind(R.id.selected_city_name)
    TextView selecteCityText;

    @Bind(R.id.current_city_list)
    RecyclerView recyclerView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selected_city_weather);
        ButterKnife.bind(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        Intent i = getIntent();

        if (i != null) {

            String cityName = i.getStringExtra("city_name");

            Log.d("MONIKA", "onResume(): cityName=" + cityName);

            selecteCityText.setText(cityName);
            presenter.findCityDetailWeather(cityName);
        }


    }

    @NonNull
    @Override
    public CityDetailWeatherPresenter createPresenter() {
        return new CityDetailWeatherPresenter();
    }

    @Override
    public void onObtainedCityDetailWeather(WeatherCityInfo weatherCityInfo) {

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false);

        recyclerView = (RecyclerView) findViewById(R.id.current_city_list);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setHasFixedSize(true);

        WeatherViewAdapter recyclerViewAdapter = new WeatherViewAdapter(CityDetailWeatherActivity.this, weatherCityInfo.getList(), WeatherViewAdapter.VIEWTYPE_HORIZONTAL);
        recyclerView.setAdapter(recyclerViewAdapter);

    }

    @Override
    public void showError(String errormsg) {
        Toast.makeText(CityDetailWeatherActivity.this, "Please check city name", Toast.LENGTH_LONG).show();
        finish();
    }
}
