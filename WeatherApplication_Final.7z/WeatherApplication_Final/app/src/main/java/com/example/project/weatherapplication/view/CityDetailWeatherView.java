package com.example.project.weatherapplication.view;


        import com.example.project.weatherapplication.model.WeatherCityInfo;
        import com.hannesdorfmann.mosby.mvp.MvpView;

public interface CityDetailWeatherView extends MvpView {

    public void showError(String errormsg);

    public void onObtainedCityDetailWeather(WeatherCityInfo weatherCityInfo);


}
