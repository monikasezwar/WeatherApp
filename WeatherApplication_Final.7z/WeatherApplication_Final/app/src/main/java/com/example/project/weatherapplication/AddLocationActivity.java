package com.example.project.weatherapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.project.weatherapplication.R;
import com.example.project.weatherapplication.presenter.AddLocationPresenter;
import com.example.project.weatherapplication.view.AddLocationView;
import com.hannesdorfmann.mosby.mvp.MvpActivity;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Monika on 14-07-2018.
 */

public class AddLocationActivity extends MvpActivity<AddLocationView, AddLocationPresenter>
        implements AddLocationView {

    @Bind(R.id.new_location)
    EditText newLocation;

    @Bind(R.id.add_location_button)
    Button addLocationButton;

    @Bind(R.id.scroll_view)
    ScrollView scrollView;

    @Bind(R.id.get_weather_info)
    Button getWeatherInfo;

    @Bind(R.id.scroll_view_container)
    LinearLayout scrollViewContainer;

    LayoutInflater mLayoutInflator;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_location);
        ButterKnife.bind(this);
        mLayoutInflator = getLayoutInflater();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @NonNull
    @Override
    public AddLocationPresenter createPresenter() {
        return new AddLocationPresenter();
    }


    @OnClick(R.id.add_location_button)
    @Override
    public void addCity() {

        presenter.addCity(newLocation.getText().toString());

        View view = mLayoutInflator.inflate(R.layout.city_item, null);

        TextView cityName = (TextView) view.findViewById(R.id.city_name);
        Button cityButton = (Button) view.findViewById(R.id.get_city_weather);
        cityName.setText(newLocation.getText());
        cityButton.setTag(newLocation.getText());

        cityButton.setOnClickListener(mCityButtonClickListener);

        scrollViewContainer.addView(view);

        newLocation.setText("");

    }



    View.OnClickListener mCityButtonClickListener = new  View.OnClickListener(){
        @Override
        public void onClick(View view) {

            Intent i = new Intent(AddLocationActivity.this, CityDetailWeatherActivity.class);
            i.putExtra("city_name", view.getTag().toString());
            startActivity(i);

        }
    };


}
