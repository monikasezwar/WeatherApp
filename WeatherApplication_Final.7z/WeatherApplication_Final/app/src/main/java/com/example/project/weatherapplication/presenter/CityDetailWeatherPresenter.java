package com.example.project.weatherapplication.presenter;


import android.util.Log;

import com.example.project.weatherapplication.adapter.WeatherAdapter;
import com.example.project.weatherapplication.model.WeatherCityInfo;
import com.example.project.weatherapplication.view.CityDetailWeatherView;
import com.hannesdorfmann.mosby.mvp.MvpBasePresenter;

import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;

public class CityDetailWeatherPresenter extends MvpBasePresenter<CityDetailWeatherView> {


    public void findCityDetailWeather(String cityname) {

        Log.d("MONIKA", "findCityDetailWeather(): cityname="+cityname);

        WeatherAdapter.getInstance().getCurentCityWeatherFor14Days(cityname)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<WeatherCityInfo>() {
                    @Override
                    public void onCompleted()
                    {
                    }
                    @Override
                    public void onError(Throwable e) {
                        getView().showError(e.getMessage());
                    }

                    @Override
                    public void onNext(WeatherCityInfo weather) {
                        getView().onObtainedCityDetailWeather(weather);
                    }
                });


    }

}
