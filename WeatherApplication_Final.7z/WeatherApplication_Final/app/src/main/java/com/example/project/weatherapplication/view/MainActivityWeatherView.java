package com.example.project.weatherapplication.view;

/**
 * Created by Monika on 13-07-2018.
 */


import com.example.project.weatherapplication.model.WeatherCityInfo;
import com.hannesdorfmann.mosby.mvp.MvpView;

public interface MainActivityWeatherView extends MvpView {

    void showLoading();
    void hideLoading();

    void showError(String error);

    void onWeatherObtained(WeatherCityInfo w);
}