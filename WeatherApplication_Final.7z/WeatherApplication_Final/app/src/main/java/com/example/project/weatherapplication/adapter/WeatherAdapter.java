package com.example.project.weatherapplication.adapter;

/**
 * Created by Monika on 13-07-2018.
 */


import android.util.Log;

import com.example.project.weatherapplication.api.WeatherAPI;
import com.example.project.weatherapplication.model.WeatherCityInfo;

import retrofit.GsonConverterFactory;
import retrofit.Retrofit;
import retrofit.RxJavaCallAdapterFactory;
import rx.Observable;

public class WeatherAdapter {

    private static WeatherAdapter instance;

    private WeatherAPI weatherAPI;

    private WeatherAdapter() {
        Retrofit retrofit = new Retrofit.Builder()
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(WeatherAPI.BASE_URL)
                .build();

        weatherAPI = retrofit.create(WeatherAPI.class);
    }

    public static WeatherAdapter getInstance() {
        if (instance == null) {
            instance = new WeatherAdapter();
        }
        return instance;
    }

    public Observable<WeatherCityInfo> getCurrentWeatherByLatLong(double lat, double lon) {
        Log.d("MONIKA","lat="+lat);
        Log.d("MONIKA","long="+lon);
        return weatherAPI.getCurrentWeatherByLatLong(lat, lon, WeatherAPI.DAYS_14,WeatherAPI.UNITS_METRIC,WeatherAPI.API_KEY);
    }

    public Observable<WeatherCityInfo> getCurentCityWeatherFor14Days(String city) {
        return weatherAPI.getCurrentWeatherByCity(city, WeatherAPI.DAYS_14, WeatherAPI.UNITS_METRIC, WeatherAPI.API_KEY);
    }


}