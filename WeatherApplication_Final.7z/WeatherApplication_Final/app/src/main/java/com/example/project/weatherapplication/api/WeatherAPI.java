package com.example.project.weatherapplication.api;



import com.example.project.weatherapplication.model.WeatherCityInfo;

import retrofit.http.GET;
import retrofit.http.Query;
import rx.Observable;

/**
 * Created by Monika on 13-07-2018.
 */

public interface WeatherAPI {

    //https://api.openweathermap.org/data/2.5/forecast?q=Bangalore&mode=json&cnt=14&appid=737ec82ce25cc942434e487ea47e49d6
    String BASE_URL = "https://api.openweathermap.org/data/2.5/forecast";

    //String BASE_URL = "http://api.openweathermap.org/data/2.5/weather";
    String API_KEY = "737ec82ce25cc942434e487ea47e49d6";

    String UNITS_METRIC = "metric";
    //String UNITS_IMPERAL = "imperial";

    int DAYS_14 = 14;

    int DAYS_1 = 1;

    @GET("forecast?")
    Observable<WeatherCityInfo> getCurrentWeatherByLatLong(@Query("lat") double lat,
                                                           @Query("lon") double lon,
                                                           @Query("cnt") int days,
                                                           @Query("units") String units,
                                                           @Query("appid") String appid);

    @GET("forecast?")
    Observable<WeatherCityInfo> getCurrentWeatherByCity(@Query("q") String city,
                                                        @Query("cnt") int days,
                                                        @Query("units") String units,
                                                        @Query("appid") String appid);


}
