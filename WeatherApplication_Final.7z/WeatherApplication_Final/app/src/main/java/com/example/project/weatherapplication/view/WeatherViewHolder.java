package com.example.project.weatherapplication.view;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.project.weatherapplication.R;

public class WeatherViewHolder extends RecyclerView.ViewHolder{

    private static final String TAG = WeatherViewHolder.class.getSimpleName();

    public TextView dayOfWeek;

    public TextView temp;

    public TextView weather;

    public TextView wind;

    public TextView humidty;


    public WeatherViewHolder(final View itemView) {
        super(itemView);

        dayOfWeek = (TextView)itemView.findViewById(R.id.day_of_week);

        temp = (TextView) itemView.findViewById(R.id.temp_result);

        weather = (TextView) itemView.findViewById(R.id.weather_text);

        wind = (TextView) itemView.findViewById(R.id.wind_text);

        humidty = (TextView) itemView.findViewById(R.id.humidity_text);


    }
}
